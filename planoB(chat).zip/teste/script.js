let score = 0; // Pontuação inicial
let baseValue = 1; // Valor base do clique
let upgrades = 0; // Número de upgrades comprados

const scoreEl = document.getElementById("score");
const baseValueEl = document.getElementById("base-value");
const upgradesEl = document.getElementById("upgrades");
const winMessage = document.getElementById("win-message");

document.getElementById("click-btn").addEventListener("click", () => {
    score += baseValue; // Adiciona o valor base ao clicar
    updateUI();
    checkWin();
});

// Função para comprar upgrades
function buyUpgrade(cost, increment) {
    if (score >= cost) {
        score -= cost; // Deduz o custo dos pontos
        baseValue += increment; // Aumenta o valor base do clique
        upgrades++; // Incrementa o número de upgrades
        updateUI();
    } else {
        alert("Você não tem pontos suficientes para comprar este upgrade!");
    }
}

// Atualiza a interface do usuário
function updateUI() {
    scoreEl.textContent = score;
    baseValueEl.textContent = baseValue;
    upgradesEl.textContent = upgrades;
}

// Verifica se o jogador alcançou 500 pontos
function checkWin() {
    if (score >= 500) {
        winMessage.classList.remove("hidden");
    }
}
