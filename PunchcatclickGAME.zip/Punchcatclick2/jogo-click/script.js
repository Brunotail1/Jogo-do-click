




//parte 100% feita com o chat, ja dizendo isso pro léo não falar AAA mas usou o chat q n sei oq tmnc claro q eu usei o chat no java script não sei quase nada//
//pedi pro chat explicar cada coisa comentando e ta ai//









// Variáveis principais do jogo
let pontuacao = 0; // Quantidade de socos atual
let valorClique = 1; // Quantidade de socos ganhos por clique

// Custos fixos dos upgrades
const custoBotao1 = 25;
const custoBotao2 = 100;
const custoBotao3 = 10000;

// Referências aos elementos do DOM
const numeroDeSocos = document.getElementById("numerodesocos");
const valorDoSoco = document.getElementById("valorsoco");
const botaoGato = document.getElementById("porcima");
const botao1 = document.querySelectorAll(".botao")[0];
const botao2 = document.querySelectorAll(".botao")[1];
const botao3 = document.querySelectorAll(".botao")[2];
const paragrafoBotao1 = document.getElementById("paragrafo-botao1");
const paragrafoBotao2 = document.getElementById("paragrafo-botao2");
const paragrafoBotao3 = document.getElementById("paragrafo-botao3");
const audioElement = document.querySelector("audio"); // Referência ao elemento de áudio

// Atualiza os elementos da interface
function atualizarInterface() {
  numeroDeSocos.innerText = pontuacao; // Atualiza o número de socos
  valorDoSoco.innerText = valorClique; // Atualiza o valor por clique
}

// Função chamada ao clicar no botão principal
botaoGato.addEventListener("click", () => {
  pontuacao += valorClique; // Aumenta a pontuação com base no valor do clique
  atualizarInterface(); // Atualiza a interface com os novos valores
});

// Função para comprar upgrades
function comprarUpgrade(custo, aumentoClique, acaoAdicional = null) {
  if (pontuacao >= custo) {
    pontuacao -= custo; // Deduz o custo do upgrade
    valorClique += aumentoClique; // Aumenta o valor do clique
    if (acaoAdicional) acaoAdicional(); // Executa ação adicional (como tocar música)
    atualizarInterface(); // Atualiza a interface
  } else {
    alert("Você não tem socos suficientes para comprar este upgrade!");
  }
}

// Função adicional para o primeiro upgrade: tocar música e exibir controles
function tocarMusica() {
  audioElement.style.display = "block"; // Mostra o controle de áudio
  audioElement.play(); // Começa a tocar a música
}

// Eventos para os botões de upgrade
botao1.addEventListener("click", () => comprarUpgrade(custoBotao1, 1, tocarMusica));
botao2.addEventListener("click", () => comprarUpgrade(custoBotao2, 8));
botao3.addEventListener("click", () => comprarUpgrade(custoBotao3, 32));

// Atualiza a interface no início do jogo
atualizarInterface();

// Oculta o controle de áudio no início
audioElement.style.display = "none";
