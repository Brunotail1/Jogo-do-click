
let pontuacao = 0; 
let valorClique = 1; 

const custoBotao1 = 25;
const custoBotao2 = 100;
const custoBotao3 = 10000;

const numeroDeSocos = document.getElementById("numerodesocos");
const valorDoSoco = document.getElementById("valorsoco");
const botaoGato = document.getElementById("porcima");
const botao1 = document.querySelectorAll(".botao")[0];
const botao2 = document.querySelectorAll(".botao")[1];
const botao3 = document.querySelectorAll(".botao")[2];
const paragrafoBotao1 = document.getElementById("paragrafo-botao1");
const paragrafoBotao2 = document.getElementById("paragrafo-botao2");
const paragrafoBotao3 = document.getElementById("paragrafo-botao3");
const audioElement = document.querySelector("audio"); 

function atualizarInterface() {
  numeroDeSocos.innerText = pontuacao; 
  valorDoSoco.innerText = valorClique; 
}
botaoGato.addEventListener("click", () => {
  pontuacao += valorClique; 
  atualizarInterface(); 
});


function comprarUpgrade(custo, aumentoClique, acaoAdicional = null) {
  if (pontuacao >= custo) {
    pontuacao -= custo; 
    valorClique += aumentoClique; 
    if (acaoAdicional) acaoAdicional(); 
    atualizarInterface(); 
  } else {
    alert("Você não é Digno!");
  }
}

function tocarMusica() {
  audioElement.style.display = "block"; 
  audioElement.play(); 
}

botao1.addEventListener("click", () => comprarUpgrade(custoBotao1, 1, tocarMusica));
botao2.addEventListener("click", () => comprarUpgrade(custoBotao2, 8));
botao3.addEventListener("click", () => comprarUpgrade(custoBotao3, 32));


atualizarInterface();

audioElement.style.display = "none";
